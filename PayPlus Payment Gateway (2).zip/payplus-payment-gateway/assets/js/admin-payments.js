jQuery(document).ready(function ($) {
    // setFieldReadOnly();
    payplusMenusDisplay();
    let changestatus = document.getElementById("payplus-change-status");

    if (changestatus) {
        changestatus.addEventListener("click", (e) => {
            event.preventDefault();
            const status = document.querySelector(".payplus-change-status");
            debugger;
            const rows = status.querySelectorAll(".payplus-row");
            rows.forEach((row) => {
                row.style.display =
                    row.style.display == "flex" ? "none" : "flex";
            });
        });
    }

    $("#display-payplus-meta-data").click(function (event) {
        event.preventDefault();
        const $button = $(this);
        const orderId = $button.data("order-id");
        const nonce = $("#payplus_display_meta_nonce").val();

        // Optional: Add a loading state to the button
        $button.prop("disabled", true).text("Loading...");

        $.ajax({
            type: "post",
            dataType: "json", // Expect a JSON response, adjust if needed
            url: payplus_script_admin.ajax_url, // Assuming this global variable holds the AJAX URL
            data: {
                action: "display-meta-data",
                order_id: orderId,
                _ajax_nonce: nonce, // Send the nonce for verification
            },
            success: function (response) {
                // Handle the successful response
                // For example, display a message or update the UI
                // Remove any existing popup first
                $("#payplus-response-popup").remove();

                // Create popup elements
                const $popupOverlay = $('<div id="payplus-response-popup"></div>').css({
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                    backgroundColor: 'rgba(0, 0, 0, 0.7)',
                    zIndex: 10000, // Ensure it's on top
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '20px'
                });

                const $popupContent = $('<div></div>').css({
                    backgroundColor: '#fff',
                    padding: '30px',
                    borderRadius: '5px',
                    maxHeight: '80vh',
                    maxWidth: '80vw',
                    overflow: 'auto',
                    position: 'relative',
                    boxSizing: 'border-box'
                });

                const $closeButton = $('<span class="close-popup">&times;</span>').css({
                    position: 'absolute',
                    top: '10px',
                    right: '15px',
                    fontSize: '24px',
                    fontWeight: 'bold',
                    cursor: 'pointer',
                    lineHeight: '1'
                });

                const $preFormattedJson = $('<pre></pre>').css({
                    whiteSpace: 'pre-wrap', // Ensure wrapping
                    wordWrap: 'break-word', // Break long words/strings
                    margin: 0 // Reset default margin
                });

                // Format and set the JSON content
                try {
                    const formattedJson = JSON.stringify(response, null, 2); // Pretty print JSON
                    $preFormattedJson.text(formattedJson);
                } catch (e) {
                    console.error("Error stringifying JSON response:", e);
                    $preFormattedJson.text("Error displaying response. See console for details.");
                }

                // Assemble the popup
                $popupContent.append($closeButton);
                $popupContent.append($preFormattedJson);
                $popupOverlay.append($popupContent);

                // Add close functionality
                $closeButton.on('click', function() {
                    $popupOverlay.fadeOut(function() { $(this).remove(); });
                });
                // Optional: Close when clicking the overlay background
                $popupOverlay.on('click', function(e) {
                    if (e.target === this) { // Only if clicking the overlay itself
                         $popupOverlay.fadeOut(function() { $(this).remove(); });
                    }
                });

                // Append to body and show
                $('body').append($popupOverlay);
                $popupOverlay.fadeIn();

                // Original logic based on response status (can still run alongside the popup)
                if (response && response.success) {
                    // alert("Meta data displayed/processed successfully."); // Replace with actual UI update
                    // Potentially reload or update part of the page based on the response
                } else {
                    alert(
                        "Error: " +
                        (response.data ? response.data : "Unknown error")
                    );
                }
                // Restore button state
                $button
                    .prop("disabled", false)
                    .text("Display Meta Data"); // Restore original text
            },
            error: function (jqXHR, textStatus, errorThrown) {
                // Handle AJAX errors
                console.error("AJAX Error:", textStatus, errorThrown);
                alert("An error occurred while processing the request.");
                // Restore button state
                $button
                    .prop("disabled", false)
                    .text("Display Meta Data"); // Restore original text
            },
        });
    });

    $(".do-api-refund-payplus").click(async function (event) {
        event.preventDefault();
        $(this).addClass("button-loading");

        const parentRow = $(this).parents("tr").attr("class").split(" ");
        const orderID = $("#post_ID").val();
        const id = $(this).attr("data-id");
        const transactionUid = $(this).attr("data-transaction-uid");
        const amount = parseFloat($(".sum-" + parentRow[1]).val());
        const method = $(this).attr("data-method");
        const refund = $(this).attr("data-refund");

        if (
            0 >= parseFloat(amount) ||
            parseFloat(amount) > parseFloat(refund)
        ) {
            $(this).removeClass("button-loading");
            alert(payplus_script_admin.payplus_refund_error);
            return false;
        }

        const data = new FormData();
        data.append("action", "payplus-refund-club-amount");
        data.append("amount", amount);
        data.append("transactionUid", transactionUid);
        data.append("method", method);
        data.append("orderID", orderID);
        data.append(
            "_ajax_nonce",
            payplus_script_admin.payplus_refund_club_amount
        );
        data.append("id", id);
        fetch(payplus_script_admin.ajax_url, {
            method: "post",
            headers: {
                Accept: "application/json",
            },
            body: data,
        })
            .then((response) => response.json())
            .then((response) => {
                $(this).removeClass("button-loading");
                location.href = response.urlredirect;
            });
    });

    $(".select-languages-payplus").change(function (event) {
        event.preventDefault();
        let language = $(this).val();
        let html = "";
        if (language) {
            let languageOther = language.split("-");
            language = language.replace(" ", "-");
            html =
                '<tr valign="top">' +
                '<th scope="row" class="titledesc">' +
                '<label for="settings_payplus_page_error_option[' +
                language +
                ']">' +
                languageOther[1] +
                "</label>" +
                "</th>" +
                '<td class="forminp forminp-textarea">' +
                '<textarea name="settings_payplus_page_error_option[' +
                language +
                ']" id="settings_payplus_page_error_option[' +
                language +
                ']" ' +
                '   style="" class="" placeholder=""></textarea>';
            "</td>" + "</tr>";
            $(".form-table").append(html);
        }
    });
    $(".copytoken").click(function (event) {
        event.preventDefault();
        var copyText = $(".copytoken");
        navigator.clipboard.writeText(copyText.text());
    });

    $("#makeTokenPayment").click(function (event) {
        event.preventDefault();
        let token = $("#ccToken").val();
        let tokenId = $("#ccToken option:selected").attr("id");

        if (
            confirm(
                payplus_script_admin.tokenPaymentConfirmMessage + tokenId + "?"
            )
        ) {
            let orderId = $(this).attr("data-id");
            let typeDocument = $(".select-type-invoice").val();
            // let sum = $(".token-payment-payplus.input-change.price").val();

            $(".payplus_loader").fadeIn();
            $.ajax({
                type: "post",
                dataType: "json",
                url: payplus_script_admin.ajax_url,
                data: {
                    action: "make-token-payment",
                    order_id: orderId,
                    token: token,
                    // paymentSum: sum,
                    typeDocument: typeDocument,
                    _ajax_nonce: payplus_script_admin.payplusTokenPayment,
                },
                success: function (response) {
                    console.log(response);
                    $(".payplus_loader").fadeOut();
                    if (response === 0) {
                        location.reload();
                    }
                },
            });
        }
    });

    function payplusSendPruidRequest(uid, orderId) {
        var loader = $("#payplus_buttons_metabox").find(".payplus_loader_gpp");
        var side = $("body").hasClass("rtl") ? "left" : "right";
        loader.css(side, "5%").css({ position: "absolute", top: "5px" });
        $("#get-invoice-plus-data").fadeOut();
        loader.fadeIn();

        $.post(ajaxurl, {
            action: "payplus_ipn",
            payment_request_uid: uid,
            order_id: orderId,
            _ajax_nonce: payplus_script_admin.payplusCustomAction,
        }, function () {
            loader.fadeOut();
            location.reload();
        });
    }

    function payplusTryAllPruids(history, orderId, index, box, overlay, initialStatus) {
        if (index >= history.length) {
            box.find("tbody tr").css("background", "");
            box.find(".pp-try-all-status").remove();
            box.append('<p class="pp-try-all-status" style="margin:12px 0 0;color:#d63638;font-weight:bold;">No approved PRUID found. None returned a successful status.</p>');
            box.find(".pp-try-all-btn").prop("disabled", false).text("Try All");
            return;
        }

        var entry = history[index];
        var rows = box.find("tbody tr");
        rows.css("background", "");
        rows.eq(index).css("background", "#fff8e1");
        box.find(".pp-try-all-status").remove();
        box.append('<p class="pp-try-all-status" style="margin:12px 0 0;color:#666;">Checking #' + (index + 1) + ' of ' + history.length + '...</p>');

        $.post(ajaxurl, {
            action: "payplus_ipn",
            payment_request_uid: entry.uid,
            order_id: orderId,
            _ajax_nonce: payplus_script_admin.payplusCustomAction,
        }).always(function () {
            $.post(ajaxurl, {
                action: "payplus_check_order_status",
                order_id: orderId,
                _ajax_nonce: payplus_script_admin.payplusCustomAction,
            }, function (statusResponse) {
                var newStatus = statusResponse && statusResponse.data && statusResponse.data.status;
                if (newStatus && newStatus !== initialStatus && newStatus !== "pending" && newStatus !== "failed" && newStatus !== "cancelled") {
                    rows.eq(index).css("background", "#e8f5e9");
                    box.find(".pp-try-all-status").remove();
                    box.append('<p class="pp-try-all-status" style="margin:12px 0 0;color:#46b450;font-weight:bold;">PRUID #' + (index + 1) + ' matched! Order status: ' + newStatus + '. Reloading...</p>');
                    setTimeout(function () { location.reload(); }, 1500);
                } else {
                    rows.eq(index).css("background", "#ffebee");
                    payplusTryAllPruids(history, orderId, index + 1, box, overlay, initialStatus);
                }
            });
        });
    }

    function payplusShowPruidSelectionModal(history, orderId) {
        $(".pp-pruid-overlay").remove();

        var overlay = $('<div class="pp-pruid-overlay"></div>').css({
            position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
            background: "rgba(0,0,0,0.5)", zIndex: 100000,
            display: "flex", alignItems: "center", justifyContent: "center"
        });

        var box = $('<div class="pp-pruid-box"></div>').css({
            background: "#fff", borderRadius: "8px", padding: "24px",
            minWidth: "420px", maxWidth: "600px", maxHeight: "80vh",
            overflowY: "auto", boxShadow: "0 4px 24px rgba(0,0,0,0.2)"
        });

        box.append('<h3 style="margin:0 0 16px;">Select a Page Request UID</h3>');

        var table = $('<table style="width:100%;border-collapse:collapse;"></table>');
        table.append('<thead><tr>' +
            '<th style="text-align:left;padding:6px 8px;border-bottom:2px solid #ddd;">#</th>' +
            '<th style="text-align:left;padding:6px 8px;border-bottom:2px solid #ddd;">UID</th>' +
            '<th style="text-align:left;padding:6px 8px;border-bottom:2px solid #ddd;">Date</th>' +
            '<th style="text-align:left;padding:6px 8px;border-bottom:2px solid #ddd;">Source</th>' +
            '<th style="padding:6px 8px;border-bottom:2px solid #ddd;"></th>' +
            '</tr></thead>');

        var tbody = $('<tbody></tbody>');
        for (var i = 0; i < history.length; i++) {
            var entry = history[i];
            var shortUid = entry.uid.length > 20 ? entry.uid.substring(0, 20) + "..." : entry.uid;
            var row = $('<tr></tr>').css("border-bottom", "1px solid #eee");
            row.append('<td style="padding:6px 8px;">' + (i + 1) + '</td>');
            row.append('<td style="padding:6px 8px;font-family:monospace;font-size:12px;" title="' + entry.uid + '">' + shortUid + '</td>');
            row.append('<td style="padding:6px 8px;font-size:12px;">' + (entry.created_at || "N/A") + '</td>');
            row.append('<td style="padding:6px 8px;font-size:12px;">' + (entry.source || "—") + '</td>');
            var useBtn = $('<button class="button button-primary" style="font-size:12px;padding:2px 10px;">Use</button>');
            (function (uid) {
                useBtn.on("click", function () {
                    overlay.remove();
                    payplusSendPruidRequest(uid, orderId);
                });
            })(entry.uid);
            var td = $('<td style="padding:6px 8px;"></td>').append(useBtn);
            row.append(td);
            tbody.append(row);
        }
        table.append(tbody);
        box.append(table);

        var footer = $('<div style="margin-top:16px;display:flex;gap:8px;justify-content:flex-end;"></div>');
        var tryAllBtn = $('<button class="button button-primary pp-try-all-btn" style="padding:4px 16px;">Try All</button>');
        tryAllBtn.on("click", function () {
            tryAllBtn.prop("disabled", true).text("Checking...");
            var currentStatus = $("#order_status").val() || "";
            currentStatus = currentStatus.replace("wc-", "");
            payplusTryAllPruids(history, orderId, 0, box, overlay, currentStatus);
        });
        var cancelBtn = $('<button class="button" style="padding:4px 16px;">Cancel</button>');
        cancelBtn.on("click", function () { overlay.remove(); });
        footer.append(tryAllBtn);
        footer.append(cancelBtn);
        box.append(footer);

        overlay.append(box);
        overlay.on("click", function (e) {
            if ($(e.target).hasClass("pp-pruid-overlay")) { overlay.remove(); }
        });
        $("body").append(overlay);
    }

    $("#custom-button-get-pp").click(function () {
        var btn = $(this);
        var orderId = btn.data("value");
        var history = btn.data("pruid-history");

        if (history && history.length > 1) {
            payplusShowPruidSelectionModal(history, orderId);
        } else {
            payplusSendPruidRequest(btn.val(), orderId);
        }
    });

    $("#create-invoice-plus-doc").click(function () {
        if (
            !confirm(
                "WARNING: This will create an invoice no matter what the order STATUS is... Are you sure you want to create the invoice?"
            )
        ) {
            return;
        }
        let loader = $("#payplus_buttons_metabox").find(".payplus_loader_gpp");
        let side = "right";

        // check if page is rtl or ltr and change the direction of the loader
        if ($("body").hasClass("rtl")) {
            side = "left";
        }

        loader.css(side, "5%");

        loader.css({
            position: "absolute",
            top: "5px",
        });
        // $("#custom-button-get-pp").fadeOut();
        // $("#get-invoice-plus-data").fadeOut();
        $("#create-invoice-plus-doc").fadeOut();
        loader.fadeIn();

        var data = {
            action: "invoice_plus_create",
            order_id: $("#create-invoice-plus-doc").data("value"),
            create_invoice: true,
            _ajax_nonce: payplus_script_admin.payplusCustomAction,
        };

        $.post(ajaxurl, data, function (response) {
            loader.fadeOut();
            location.reload();
        });
    });

    $("#get-invoice-plus-data").click(function () {
        if (
            !confirm(
                "ATTENTION: This only pulls existing information, only visual data, this does not create any document."
            )
        ) {
            return;
        }
        let loader = $("#payplus_buttons_metabox").find(".payplus_loader_gpp");
        let side = "right";

        // check if page is rtl or ltr and change the direction of the loader
        if ($("body").hasClass("rtl")) {
            side = "left";
        }

        loader.css(side, "5%");

        loader.css({
            position: "absolute",
            top: "5px",
        });
        // $("#custom-button-get-pp").fadeOut();
        // $("#get-invoice-plus-data").fadeOut();
        $("#create-invoice-plus-doc").fadeOut();
        loader.fadeIn();

        var data = {
            action: "invoice_plus_search",
            transaction_uuid: $("#get-invoice-plus-data").val(),
            order_id: $("#get-invoice-plus-data").data("value"),
            get_invoice: true,
            _ajax_nonce: payplus_script_admin.payplusCustomAction,
        };

        $.post(ajaxurl, data, function (response) {
            loader.fadeOut();
            location.reload();
        });
    });

    $(document).on("click", "#payment-payplus-transaction", function (event) {
        event.preventDefault();
        let orderId = $(this).attr("data-id");
        $(".payplus_loader").fadeIn();
        $.ajax({
            type: "post",
            dataType: "json",
            url: payplus_script_admin.ajax_url,
            data: {
                action: "payment-payplus-transaction-review",
                order_id: orderId,
                _ajax_nonce: payplus_script_admin.payplusTransactionReview,
            },
            success: function (response) {
                $("#payment-payplus-dashboard,.payplus_loader").fadeOut();
                if (response.status) {
                    location.href = response.urlredirect;
                }
            },
        });
    });

    $(document).on(
        "click",
        "#payment-payplus-dashboard, #payment-payplus-dashboard-emv",
        function (event) {
            event.preventDefault();
            let orderId = $(this).attr("data-id");
            let $this = $(this);
            $this
                .parent(".payment-order-ajax")
                .find(".payplus_loader")
                .fadeIn();
            $.ajax({
                type: "post",
                dataType: "json",
                url: payplus_script_admin.ajax_url,
                data: {
                    action: "generate-link-payment",
                    order_id: orderId,
                    button: $this.attr("id"),
                    _ajax_nonce:
                        payplus_script_admin.payplusGenerateLinkPayment,
                },
                success: function (response) {
                    console.log(response);
                    if ($this.attr("id") === "payment-payplus-dashboard-emv") {
                        //for device transaction.
                        const parsedResponse = JSON.parse(response.body);
                        if (
                            parsedResponse?.results?.status === "success" &&
                            parsedResponse?.results?.code === 0
                        ) {
                            location.reload();
                        } else if (
                            parsedResponse?.results?.status === "error" &&
                            parsedResponse?.results?.code === 1
                        ) {
                            alert(parsedResponse?.results?.description);
                            $this
                                .parent(".payment-order-ajax")
                                .find(".payplus_loader")
                                .fadeOut();
                        }
                        //for device transaction.
                    } else {
                        $("#box-payplus-payment").fadeIn();
                        $this
                            .parent(".payment-order-ajax")
                            .find(".payplus_loader")
                            .fadeOut();

                        if (response.status) {
                            $this.fadeOut();
                            $("#box-payplus-payment iframe").attr(
                                "src",
                                response.payment_response
                            );
                        } else {
                            $("#box-payplus-payment").text(
                                response.payment_response
                            );
                        }
                    }
                },
            });
        }
    );
    $("#order-payment-payplus").click(function (event) {
        event.preventDefault();
        let orderId = $(this).attr("data-id");
        $(".payplus_loader").fadeIn();
        $.ajax({
            type: "post",
            dataType: "json",
            url: payplus_script_admin.ajax_url,
            data: {
                action: "payplus-api-payment",
                order_id: orderId,
                _ajax_nonce: payplus_script_admin.payplusApiPayment,
            },
            success: function (response) {
                $(".payplus_loader").fadeOut();
                //if(response.status){
                location.href = response.urlredirect;
                // }
            },
        });
    });

    $("#payplus-token-payment").click(function (event) {
        event.preventDefault();
        let payplusChargeAmount = $(this)
            .closest(".delayed-payment")
            .find("#payplus_charge_amount")
            .val(),
            payplusOrderId = $(this)
                .closest(".delayed-payment")
                .find("#payplus_order_id")
                .val();
        $(this).closest(".delayed-payment").find(".payplus_loader").fadeIn();
        $("#payplus-token-payment").prop("disabled", true);
        $.ajax({
            type: "post",
            dataType: "json",
            url: payplus_script_admin.ajax_url,
            data: {
                action: "payplus-token-payment",
                payplus_charge_amount: payplusChargeAmount,
                payplus_order_id: payplusOrderId,
                payplus_token_payment: true,
                _ajax_nonce: payplus_script_admin.payplusTokenPayment,
            },
            beforeSend: function () {
                const targetNode = document.querySelector(".payplus_error");
                const observer = new MutationObserver(
                    (mutationsList, observer) => {
                        for (let mutation of mutationsList) {
                            if (
                                mutation.type === "attributes" &&
                                mutation.attributeName === "style"
                            ) {
                                if (targetNode.style.display !== "none") {
                                } else {
                                    $(".payplus_loader").fadeOut();
                                }
                            }
                        }
                    }
                );
                const config = { attributes: true, attributeFilter: ["style"] };
                observer.observe(targetNode, config);
            },
            success: function (response) {
                $(this)
                    .closest(".delayed-payment")
                    .find(".payplus_loader")
                    .fadeOut();
                if (!response.status) {
                    $(".payplus_error")
                        .html(payplus_script_admin.error_payment)
                        .fadeIn(function () {
                            setTimeout(function () {
                                $("#payplus-token-payment").prop(
                                    "disabled",
                                    false
                                );
                                $(".payplus_error").fadeOut("fast");
                                $("#payplus_charge_amount").val(
                                    $("#payplus_charge_amount").attr(
                                        "data-amount"
                                    )
                                );
                            }, 1000);
                        });
                } else {
                    location.href = response.urlredirect;
                }
            },
            error: function (xhr, status, error) {
                let errorMessage = xhr.responseText.split("&error=")[1]
                    ? xhr.responseText.split("&error=")[1]
                    : "Failed, please check the order notes for the failure reason.";
                alert(errorMessage);
                // location.reload();
            },
        });
    });
});
function setFieldReadOnly() {
    const arrNameFieldReadOnly = jQuery("#postcustom input[type='text']");

    for (let i = 0; i < arrNameFieldReadOnly.length; i++) {
        const metaName = jQuery(arrNameFieldReadOnly[i]).attr("id");
        const metaValue = metaName.replace("key", "value");
        if (
            jQuery("#" + metaName)
                .val()
                .indexOf("payplus") != -1
        ) {
            const father = metaName.replace("-key", "");
            jQuery("#" + metaName).prop("disabled", true);
            jQuery("#" + metaValue).prop("disabled", true);
            jQuery("#" + father)
                .find(".button")
                .prop("disabled", true);
        }
    }

    const metaName = jQuery("#postcustom input[value='order_validated']").attr(
        "id"
    );

    if (typeof metaName != "undefined") {
        const metaValue = metaName.replace("key", "value");
        const father = metaName.replace("-key", "");
        jQuery("#" + metaName).prop("disabled", true);
        jQuery("#" + metaValue).prop("disabled", true);
        jQuery("#" + father)
            .find(".button")
            .prop("disabled", true);
    }
}
function payPlusSumRefund() {
    const arrRefundAmount = ["refund_amount"];
    let sum = 0;
    const isEmpty = (str) => !str?.length;
    for (let i = 0; i < arrRefundAmount.length; i++) {
        if (!isEmpty(jQuery("#" + arrRefundAmount[i]).val())) {
            sum += parseFloat(jQuery("#" + arrRefundAmount[i]).val());
        }
    }
    return sum.toFixed(2);
}

var $saveButton = jQuery('button[name="save"]');
var $specificDiv = jQuery("#settingsContainer");

const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const section = urlParams.get("section");
let currentLanguage = payplus_script_admin.currentLanguage.substring(0, 2);

if (currentLanguage !== "en" && currentLanguage !== "he") {
    currentLanguage = "en";
}

if (
    section == "payplus-invoice" ||
    section == "payplus-payment-gateway-setup-wizard" ||
    section == "payplus-express-checkout" ||
    section == "payplus-error-setting" ||
    section == "payplus-payment-gateway"
) {
    jQuery(window).on("scroll", function () {
        var offset = $specificDiv.offset();
        var scrollTop = jQuery(window).scrollTop();
        let sideAmount = "2%";
        if (
            jQuery(".right-tab-section-payplus").length &&
            jQuery(window).width() > 1400 &&
            jQuery(".right-tab-section-payplus").css("display") !== "none"
        ) {
            sideAmount = "37.5%";
        }
        let side = "right";
        if (jQuery("body").hasClass("rtl")) {
            side = "left";
        }

        if (scrollTop >= offset?.top) {
            $saveButton.css({
                position: "fixed",
                top: "80%",
            });
            $saveButton.css(side, sideAmount);
        } else {
            $saveButton.css({
                position: "fixed",
                top: "80%",
            });
            $saveButton.css(side, sideAmount);
        }
    });

    function showDevs() {
        jQuery("#woocommerce_payplus-payment-gateway_dev_api_key")
            .closest("tr")
            .show();
        jQuery("#woocommerce_payplus-payment-gateway_dev_secret_key")
            .closest("tr")
            .show();
        jQuery("#woocommerce_payplus-payment-gateway_dev_payment_page_id")
            .closest("tr")
            .show();
        jQuery("#woocommerce_payplus-payment-gateway_dev_device_uid")
            .closest("tr")
            .show();
        jQuery("#woocommerce_payplus-payment-gateway_dev_secret_key")
            .closest("tr")
            .find("label")
            .css({ color: "#34aa54" });
        jQuery("#woocommerce_payplus-payment-gateway_dev_api_key")
            .closest("tr")
            .find("label")
            .css({ color: "#34aa54" });
        jQuery("#woocommerce_payplus-payment-gateway_dev_payment_page_id")
            .closest("tr")
            .find("label")
            .css({ color: "#34aa54" });
        jQuery("#woocommerce_payplus-payment-gateway_dev_device_uid")
            .closest("tr")
            .find("label")
            .css({ color: "#34aa54" });
        jQuery("#woocommerce_payplus-payment-gateway_api_key")
            .closest("tr")
            .hide();
        jQuery("#woocommerce_payplus-payment-gateway_secret_key")
            .closest("tr")
            .hide();
        jQuery("#woocommerce_payplus-payment-gateway_payment_page_id")
            .closest("tr")
            .hide();
        jQuery("#woocommerce_payplus-payment-gateway_device_uid")
            .closest("tr")
            .hide();
    }

    function showProds() {
        jQuery("#woocommerce_payplus-payment-gateway_dev_api_key")
            .closest("tr")
            .hide();
        jQuery("#woocommerce_payplus-payment-gateway_dev_secret_key")
            .closest("tr")
            .hide();
        jQuery("#woocommerce_payplus-payment-gateway_dev_payment_page_id")
            .closest("tr")
            .hide();
        jQuery("#woocommerce_payplus-payment-gateway_dev_device_uid")
            .closest("tr")
            .hide();
        jQuery("#woocommerce_payplus-payment-gateway_api_key")
            .closest("tr")
            .show();
        jQuery("#woocommerce_payplus-payment-gateway_secret_key")
            .closest("tr")
            .show();
        jQuery("#woocommerce_payplus-payment-gateway_payment_page_id")
            .closest("tr")
            .show();
        jQuery("#woocommerce_payplus-payment-gateway_device_uid")
            .closest("tr")
            .show();
        jQuery("#woocommerce_payplus-payment-gateway_secret_key")
            .closest("tr")
            .find("label")
            .css({ color: "#34aa54" });
        jQuery("#woocommerce_payplus-payment-gateway_api_key")
            .closest("tr")
            .find("label")
            .css({ color: "#34aa54" });
        jQuery("#woocommerce_payplus-payment-gateway_payment_page_id")
            .closest("tr")
            .find("label")
            .css({ color: "#34aa54" });
        jQuery("#woocommerce_payplus-payment-gateway_device_uid")
            .closest("tr")
            .find("label")
            .css({ color: "#34aa54" });
    }

    var brandUidParentTr = jQuery(
        "#payplus_invoice_option\\[payplus_invoice_brand_uid\\]"
    ).closest("tr");
    var brandUidDevParentTr = jQuery(
        "#payplus_invoice_option\\[payplus_invoice_brand_uid_sandbox\\]"
    ).closest("tr");
    var emvPosBrandUidParentTr = jQuery(
        "#payplus_invoice_option\\[payplus_invoice_emv_pos_brand_uid\\]"
    ).closest("tr");
    var emvPosBrandUidDevParentTr = jQuery(
        "#payplus_invoice_option\\[payplus_invoice_emv_pos_brand_uid_sandbox\\]"
    ).closest("tr");

    if (payplus_script_admin.testMode === "yes") {
        brandUidParentTr.hide();
        emvPosBrandUidParentTr.hide();
    } else {
        brandUidDevParentTr.hide();
        emvPosBrandUidDevParentTr.hide();
    }

    jQuery("#woocommerce_payplus-payment-gateway_api_test_mode").change(
        function () {
            if (
                jQuery(
                    "#woocommerce_payplus-payment-gateway_api_test_mode"
                ).val() === "yes"
            ) {
                showDevs();
            } else if (
                jQuery(
                    "#woocommerce_payplus-payment-gateway_api_test_mode"
                ).val() === "no"
            ) {
                showProds();
            }
        }
    );

    let currentMode;
    let modeMessage = [];
    // display  Add Apple Pay Script to iframe button
    // const isApplePayEnabled = payplus_script_admin.isApplePayEnabled;

    // isApplePayEnabled
    //   ? jQuery("#woocommerce_payplus-payment-gateway_import_applepay_script")
    //       .closest("tr")
    //       .fadeIn()
    //   : jQuery("#woocommerce_payplus-payment-gateway_import_applepay_script")
    //       .closest("tr")
    //       .fadeOut();
    // display allow amount change button and J5 weight estimate fields
    var isAuthorization = Number(
        jQuery("#woocommerce_payplus-payment-gateway_transaction_type").val()
    ) === 2;

    if (!isAuthorization) {
        jQuery("#woocommerce_payplus-payment-gateway_check_amount_authorization").closest("tr").fadeOut();
        jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_enabled").closest("tr").fadeOut();
        jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_percentage").closest("tr").fadeOut();
        jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_name").closest("tr").fadeOut();
        jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_message").closest("tr").fadeOut();
    } else {
        jQuery("#woocommerce_payplus-payment-gateway_check_amount_authorization").closest("tr").fadeIn();
        jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_enabled").closest("tr").fadeIn();
        if (jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_enabled").is(":checked")) {
            jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_percentage").closest("tr").fadeIn();
            jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_name").closest("tr").fadeIn();
            jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_message").closest("tr").fadeIn();
        } else {
            jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_percentage").closest("tr").fadeOut();
            jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_name").closest("tr").fadeOut();
            jQuery("#woocommerce_payplus-payment-gateway_j5_weight_estimate_message").closest("tr").fadeOut();
        }
    }
    //display API mode
    if (
        jQuery("#woocommerce_payplus-payment-gateway_api_test_mode").val() ===
        "yes"
    ) {
        modeMessage["en"] = "Current Mode: Sandbox(Development) mode";
        modeMessage["he"] = "מצב נוכחי: מצב ארגז חול(פיתוח)";
        currentMode = jQuery(
            "<tr><td style='color: red;' id='currentMode'>" +
            modeMessage[currentLanguage] +
            "</td></tr></tr>"
        );
        showDevs();
    } else {
        if (
            jQuery(
                "#woocommerce_payplus-payment-gateway_api_test_mode"
            ).val() === "no"
        ) {
            modeMessage["en"] = "Current Mode: Production mode";
            modeMessage["he"] = "מצב נוכחי: מצב ייצור";
            currentMode = jQuery(
                "<tr><td id='currentMode'>" +
                modeMessage[currentLanguage] +
                "</td></tr></tr>"
            );
            showProds();
        }
    }
    var $firstInputWithId = jQuery("#mainform input[id]").first();
    $firstInputWithId.closest("tr").before(currentMode);
}

/**
 * Function to create, update, and set the designed admin settings.
 *
 * @param {string} paramName - Description of the parameter.
 * @returns {void} Description of the return value.
 */
function payplusMenusDisplay() {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const section = urlParams.get("section");
    const transactionType = payplus_script_admin.payplusTransactionType;
    const $checkAmountAuthorization = jQuery(
        "#woocommerce_payplus-payment-gateway_check_amount_authorization"
    );
    const $transactionType = jQuery(
        "#woocommerce_payplus-payment-gateway_transaction_type"
    );
    const $j5WeightEnabled = jQuery(
        "#woocommerce_payplus-payment-gateway_j5_weight_estimate_enabled"
    );
    const $j5WeightPercentage = jQuery(
        "#woocommerce_payplus-payment-gateway_j5_weight_estimate_percentage"
    );
    const $j5WeightName = jQuery(
        "#woocommerce_payplus-payment-gateway_j5_weight_estimate_name"
    );
    const $j5WeightMessage = jQuery(
        "#woocommerce_payplus-payment-gateway_j5_weight_estimate_message"
    );

    $transactionType.change(function (e) {
        if (Number(e.target.value) === 2) {
            $checkAmountAuthorization.closest("tr").fadeIn();
            $j5WeightEnabled.closest("tr").fadeIn();
            if ($j5WeightEnabled.is(":checked")) {
                $j5WeightPercentage.closest("tr").fadeIn();
                $j5WeightName.closest("tr").fadeIn();
                $j5WeightMessage.closest("tr").fadeIn();
            }
        } else {
            $checkAmountAuthorization.closest("tr").fadeOut();
            $j5WeightEnabled.closest("tr").fadeOut();
            $j5WeightPercentage.closest("tr").fadeOut();
            $j5WeightName.closest("tr").fadeOut();
            $j5WeightMessage.closest("tr").fadeOut();
        }
    });

    $j5WeightEnabled.change(function () {
        if (jQuery(this).is(":checked")) {
            $j5WeightPercentage.closest("tr").fadeIn();
            $j5WeightName.closest("tr").fadeIn();
            $j5WeightMessage.closest("tr").fadeIn();
        } else {
            $j5WeightPercentage.closest("tr").fadeOut();
            $j5WeightName.closest("tr").fadeOut();
            $j5WeightMessage.closest("tr").fadeOut();
        }
    });

    if (
        section === "payplus-payment-gateway-multipass" &&
        Number(transactionType) === 2
    ) {
        let message = [];
        message["en"] =
            "Authorization Mode On - MULTIPASS will not be displayed on the PayPlus payment page!";
        message["he"] =
            "מצב תפיסת מסגרת מופעל - מולטיפס לא יופיע בעמוד החיוב של פייפלוס!";

        let transactionTypeMessage;
        var $firstInputWithId = jQuery("#mainform input[id]").first();

        transactionTypeMessage = jQuery(
            "<tr><td id='warningMessage'>" +
            message[currentLanguage] +
            "</td></tr></tr>"
        );
        $firstInputWithId.closest("tr").before(transactionTypeMessage);
    }
    const $selectCards = document.querySelector(
        "#woocommerce_payplus-payment-gateway_settings\\[cards\\]"
    )?.parentElement?.parentElement?.parentElement?.parentElement;
    const $checkOutPageOptions = document.querySelector(
        "#woocommerce_payplus-payment-gateway_hide_icon"
    )?.parentElement?.parentElement?.parentElement?.parentElement
        ?.parentElement;

    $checkOutPageOptions?.append($selectCards);
    if (
        section == "payplus-invoice" ||
        section == "payplus-payment-gateway-setup-wizard" ||
        section == "payplus-express-checkout" ||
        section == "payplus-error-setting" ||
        section == "payplus-payment-gateway-hostedfields" ||
        section == "payplus-payment-gateway-multipass"
    ) {
        //don't display on multipass but use the other display settings ...:)
        //this displays the top 3 payplus settings invoice settings and express checkout tabs - above the subgateways...
        //next if is not to display twice because we already loaded it.
        if (
            section !== "payplus-payment-gateway-multipass" &&
            section !== "payplus-payment-gateway-hostedfields"
        ) {
            jQuery(".wrap.woocommerce")
                .find("h1")
                .before(payplus_script_admin.menu_option);
        }

        const formTables = jQuery(".wrap.woocommerce").find(".form-table");
        formTables.each(function () {
            if (this.innerHTML.trim().length === 0) {
                this.style.display = "none";
            }
        });

        let classes = [
            ".payplus-api",
            ".payplus-languages-class",
            ".payplus-documents",
            ".payplus-vat",
            ".payplus-display",
            ".payplus-notifications",
        ];
        let headLines = [];

        headLines[".payplus-api"] =
            currentLanguage === "he" ? "הגדרות API" : "Api Settings";
        headLines[".payplus-languages-class"] =
            currentLanguage === "he" ? "הגדרות שפה" : "Language Settings";
        headLines[".payplus-documents"] =
            currentLanguage === "he" ? "הגדרות מסמכים" : "Document Settings";
        headLines[".payplus-vat"] =
            currentLanguage === "he" ? 'הגדרות מע"מ' : "VAT Settings";
        headLines[".payplus-display"] =
            currentLanguage === "he" ? "הגדרות תצוגה" : "Display Settings";
        headLines[".payplus-notifications"] =
            currentLanguage === "he" ? "התראות" : "Notifications";

        let tables = {};
        //Create settingsContainer
        let translated = [];

        translated["iframeHeadline"] = [];
        translated["iframeHeadline"]["he"] = "פייפלוס שאלות ותשובות";
        translated["iframeHeadline"]["en"] = "PayPlus FAQ";

        const iframeHeadline = translated["iframeHeadline"][currentLanguage];

        const iframes = [];
        iframes["payplus-invoice"] =
            '<iframe height="97%" width="80%" src="https://www.payplus.co.il/faq/%D7%97%D7%A9%D7%91%D7%95%D7%A0%D7%99%D7%AA-/%D7%94%D7%AA%D7%9E%D7%9E%D7%A9%D7%A7%D7%95%D7%AA-%D7%9C%D7%97%D7%A0%D7%95%D7%99%D7%95%D7%AA-%D7%90%D7%99%D7%A0%D7%98%D7%A8%D7%A0%D7%98%D7%99%D7%95%D7%AA/%D7%97%D7%99%D7%91%D7%95%D7%A8-%D7%97%D7%A9%D7%91%D7%95%D7%A0%D7%99%D7%AA--%D7%9C%D7%97%D7%A0%D7%95%D7%AA-WooCommerce"></iframe>';
        iframes["payplus-faq"] =
            '<iframe height="97%" width="80%" src="https://www.payplus.co.il/faq/"></iframe>';

        let iframeToShow =
            section === "payplus-invoice"
                ? iframes["payplus-invoice"]
                : iframes["payplus-faq"];
        let $settingsContainer = jQuery(
            '<div id="settingsContainer"><div class="tab-section-payplus" id="tab-payplus-gateway"></div><div class="right-tab-section-payplus hideIt"><h2>' +
            iframeHeadline +
            "</h2></div>"
        );
        //Add all existing tables to .tab-section-payplus
        $settingsContainer
            .find(".tab-section-payplus")
            .append(jQuery(".form-table"));
        jQuery("#mainform").children().last().before($settingsContainer);
        jQuery(".right-tab-section-payplus").css({
            padding: "0 0 5% 0",
            display: "block",
            textAlign: "center",
        });

        if (section === "payplus-invoice") {
            let generalSettings =
                currentLanguage === "he" ? "הגדרות כלליות" : "General Settings";
            var headline = "<h2>" + generalSettings + "</h2>";
            jQuery(".tab-section-payplus").prepend(headline);
        }

        if ($settingsContainer.height() < 300) {
            jQuery(".right-tab-section-payplus").css("display", "none");
        }

        if (jQuery.inArray(section, ["payplus-invoice"]) >= 0) {
            for (let i = 0; i < classes.length; i++) {
                let $thead = jQuery("<thead></thead>");
                let $headerRow = jQuery("<tr></tr>");
                let $tbody = jQuery("<tbody></tbody>");
                $tbody.css("width", "100%");
                $thead.append($headerRow);

                let $movableElements = jQuery(classes[i]).parent().parent();
                $movableElements.each(function (e) {
                    if (
                        $movableElements[e].tagName.toLowerCase() === "fieldset"
                    ) {
                        $movableElements[e] = jQuery($movableElements[e])
                            .parent()
                            .parent()[0];
                    }
                });

                $movableElements.detach();
                let $table = jQuery("<table></table>").addClass("form-table");
                $table.css("margin-top", "10px");

                // if (jQuery(window).width() > 1400) {
                //   jQuery(".form-table").css("width", "60%");
                // }
                $table.append($thead);
                $table.append($tbody);

                $movableElements.appendTo($table);
                if (classes[i] !== ".payplus-api") {
                    //add the fixed tables to .tab-section-payplus
                    $settingsContainer
                        .find(".tab-section-payplus")
                        .append("<h2>" + headLines[classes[i]] + "</h2>");
                    $settingsContainer
                        .find(".tab-section-payplus")
                        .append($table);
                }
            }
            jQuery("h2").css("color", "#34aa54");
        }
    }

    // ── Device UID Map (EMV POS) ──────────────────────────────────────────
    (function ($) {
        var i18n =
            typeof payplus_script_admin !== "undefined" &&
            payplus_script_admin.duid_i18n
                ? payplus_script_admin.duid_i18n
                : {};

        function rebuildValue($container) {
            
            // Extract field name from container class
            var classes = $container.attr('class').split(' ');
            var fieldName = '';
            for (var i = 0; i < classes.length; i++) {
                if (classes[i].indexOf('payplus-duid-field-') === 0) {
                    fieldName = classes[i].replace('payplus-duid-field-', '');
                    break;
                }
            }
            
            if (!fieldName) {
                console.error('PayPlus Device UID Map: Could not find field name from container classes');
                return;
            }
            
            var fieldId = 'woocommerce_payplus-payment-gateway_' + fieldName;
            
            var $allRows = $container.find(".payplus-duid-row");
            
            var parts = [];
            $allRows.each(function (index) {
                // Extract userId from class name (payplus-duid-userid-123)
                var classes = $(this).attr('class').split(' ');
                var userId = '';
                for (var i = 0; i < classes.length; i++) {
                    if (classes[i].indexOf('payplus-duid-userid-') === 0) {
                        userId = classes[i].replace('payplus-duid-userid-', '');
                        break;
                    }
                }
                var uid = $(this).find(".payplus-duid-input").val().trim();
                if (userId && uid) {
                    parts.push(userId + ":" + uid);
                }
            });
            var newValue = parts.join(",");
            $("#" + fieldId).val(newValue);
            checkDuplicates($container);
        }

        function checkDuplicates($container) {
            var seen = {};
            var dupes = {};
            $container.find(".payplus-duid-input").each(function () {
                var val = $(this).val().trim();
                if (val) {
                    if (seen[val]) {
                        dupes[val] = true;
                    }
                    seen[val] = true;
                }
            });
            $container.find(".payplus-duid-input").each(function () {
                var val = $(this).val().trim();
                if (val && dupes[val]) {
                    $(this).addClass("payplus-duid-duplicate");
                    $(this).attr("title", i18n.duplicate || "Duplicate UID");
                } else {
                    $(this).removeClass("payplus-duid-duplicate");
                    $(this).removeAttr("title");
                }
            });
        }

        function toggleEmptyHint($container) {
            var $rows = $container.find(".payplus-duid-row");
            var $hint = $container.find(".payplus-duid-empty-hint");
            if ($rows.length === 0) {
                if ($hint.length === 0) {
                    $container
                        .find(".payplus-duid-rows")
                        .after(
                            '<p class="payplus-duid-empty-hint description">' +
                                (i18n.emptyHint || "") +
                                "</p>"
                        );
                } else {
                    $hint.show();
                }
            } else {
                $hint.hide();
            }
        }

        function escHtml(str) {
            return $("<span>").text(str).html();
        }

        // Add User button.
        $(document).on("click", ".payplus-duid-add-btn", function (e) {
            e.preventDefault();
            var $container = $(this).closest(".payplus-device-uid-map");
            var $select = $container.find(".payplus-duid-user-select");
            var $option = $select.find("option:selected");
            var userId = $select.val();

            if (!userId) {
                return;
            }

            // Parse user info from option text: "Name (login, ID: 123)"
            var optionText = $option.text();
            var userName = '';
            var userLogin = '';
            var userDisplay = optionText;
            
            // Extract name and login from text
            var match = optionText.match(/^(.+?)\s+\((.+?),\s+ID:\s+\d+\)$/);
            if (match) {
                userName = match[1];
                userLogin = match[2];
            }

            var row =
                '<div class="payplus-duid-row payplus-duid-userid-' +
                userId +
                '" data-user-name="' +
                escHtml(userName) +
                '" data-user-login="' +
                escHtml(userLogin) +
                '">' +
                '<div class="payplus-duid-row-header">' +
                '<span class="payplus-duid-user-label"><span class="dashicons dashicons-admin-users"></span> ' +
                escHtml(userDisplay) +
                "</span>" +
                '<span class="button-link payplus-duid-remove-btn" role="button" tabindex="0" title="' +
                escHtml(i18n.remove || "Remove") +
                '"><span class="dashicons dashicons-no-alt"></span></span>' +
                "</div>" +
                '<div class="payplus-duid-row-body">' +
                "<label>" +
                escHtml(i18n.deviceUid || "Device UID:") +
                "</label>" +
                '<input type="text" class="payplus-duid-input regular-text" value="" placeholder="' +
                escHtml(i18n.enterUid || "") +
                '" />' +
                "</div>" +
                "</div>";

            $container.find(".payplus-duid-rows").append(row);
            $option.remove();
            $select.val("");
            toggleEmptyHint($container);
            rebuildValue($container);
        });

        // Remove row button.
        $(document).on("click", ".payplus-duid-remove-btn", function (e) {
            e.preventDefault();
            var $row = $(this).closest(".payplus-duid-row");
            var $container = $row.closest(".payplus-device-uid-map");
            var $select = $container.find(".payplus-duid-user-select");
            
            // Extract userId from class name
            var classes = $row.attr('class').split(' ');
            var userId = '';
            for (var i = 0; i < classes.length; i++) {
                if (classes[i].indexOf('payplus-duid-userid-') === 0) {
                    userId = classes[i].replace('payplus-duid-userid-', '');
                    break;
                }
            }
            var userName = $row.data("user-name");
            var userLogin = $row.data("user-login");

            // Re-add to dropdown if user name is available (not a deleted user).
            if (userName && userLogin) {
                var optionText =
                    userName + " (" + userLogin + ", ID: " + userId + ")";
                $select.append(
                    $("<option>", { value: userId, text: optionText })
                );
            }

            $row.remove();
            toggleEmptyHint($container);
            rebuildValue($container);
        });

        // UID input change — rebuild value.
        $(document).on("input", ".payplus-duid-input", function () {
            var $container = $(this).closest(".payplus-device-uid-map");
            rebuildValue($container);
        });
    })(jQuery);
}
